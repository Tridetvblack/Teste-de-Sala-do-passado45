
async function acao(tipo) {
  const ra = prompt("Digite seu RA:");
  const senha = prompt("Digite sua senha:");

  if (!ra || !senha) {
    alert("Preencha o RA e a senha para continuar.");
    return;
  }

  const resposta = await fetch("https://sala-do-passado-api.onrender.com/api/acao", {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify({ ra, senha, tipo })
  });

  const dados = await resposta.json();
  alert(dados.msg);

  const fala = new SpeechSynthesisUtterance(dados.msg);
  speechSynthesis.speak(fala);
}
