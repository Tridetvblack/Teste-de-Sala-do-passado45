# Sala do Passado

Frontend com visual de meme + backend real com MongoDB e autenticação.