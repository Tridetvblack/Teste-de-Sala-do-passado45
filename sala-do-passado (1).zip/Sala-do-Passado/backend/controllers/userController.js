
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const User = require('../models/User');

const mensagens = {
  redacao: "Redação enviada com sucesso!",
  tarefa: "Tarefa concluída com sucesso!",
  expansao: "Expansão noturna registrada!",
  alura: "Curso Alura finalizado!"
};

exports.loginOuAcao = async (req, res) => {
  const { ra, senha, tipo } = req.body;
  const user = await User.findOne({ ra });

  if (!user) return res.json({ msg: "Usuário não encontrado." });

  const ok = await bcrypt.compare(senha, user.senha);
  if (!ok) return res.json({ msg: "Senha incorreta." });

  res.json({ msg: mensagens[tipo] || "Ação desconhecida." });
};
