
const express = require('express');
const router = express.Router();
const { loginOuAcao } = require('../controllers/userController');

router.post('/acao', loginOuAcao);

module.exports = router;
